/*document.addEventListener('DOMContentLoaded', function () {
    document.querySelector('#showAlert').addEventListener('change', changeHandler);
});*/